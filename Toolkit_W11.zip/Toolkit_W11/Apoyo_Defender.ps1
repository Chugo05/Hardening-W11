﻿# ==============================================================================
# Herramienta 2: Fortificador de Windows Defender
# ==============================================================================

# Comprobacion de privilegios
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Warning "Ejecuta como Administrador."; pause; exit }

# ==============================================================================
# COMPROBACION DEL SERVICIO DE WINDOWS DEFENDER
# ==============================================================================
$defenderService = Get-Service -Name "WinDefend" -ErrorAction SilentlyContinue

if ($null -eq $defenderService) {
    Write-Host "######################################################" -ForegroundColor Red
    Write-Host " ERROR: El servicio WinDefend no existe en este equipo." -ForegroundColor Red
    Write-Host " Es posible que Defender haya sido reemplazado por un" -ForegroundColor Red
    Write-Host " antivirus de terceros o desinstalado manualmente." -ForegroundColor Red
    Write-Host "######################################################" -ForegroundColor Red
    pause; return
}

if ($defenderService.Status -ne "Running") {
    Write-Host "======================================================" -ForegroundColor Yellow
    Write-Host " AVISO: El servicio WinDefend esta detenido." -ForegroundColor Yellow
    Write-Host " Estado actual: $($defenderService.Status)" -ForegroundColor Yellow
    Write-Host " Intentando iniciarlo..." -ForegroundColor Yellow
    Write-Host "======================================================" -ForegroundColor Yellow

    try {
        Start-Service -Name "WinDefend" -ErrorAction Stop
        Start-Sleep -Seconds 2
        Write-Host " Servicio iniciado correctamente." -ForegroundColor Green
    }
    catch {
        Write-Host "######################################################" -ForegroundColor Red
        Write-Host " ERROR: No se pudo iniciar WinDefend." -ForegroundColor Red
        Write-Host " Causa probable: Defender deshabilitado por GPO," -ForegroundColor Red
        Write-Host " por un antivirus de terceros, o por tamper protection." -ForegroundColor Red
        Write-Host "" -ForegroundColor Red
        Write-Host " Soluciones:" -ForegroundColor Yellow
        Write-Host "  1. Abre Seguridad de Windows > Proteccion antivirus" -ForegroundColor Yellow
        Write-Host "     y reactiva Defender manualmente." -ForegroundColor Yellow
        Write-Host "  2. Si tienes otro antivirus instalado, desinstalalo" -ForegroundColor Yellow
        Write-Host "     primero para que Defender vuelva a activarse." -ForegroundColor Yellow
        Write-Host "  3. Ejecuta en cmd elevado: sc config WinDefend start= auto" -ForegroundColor Yellow
        Write-Host "######################################################" -ForegroundColor Red
        pause; return
    }
}

# ==============================================================================
# MENU PRINCIPAL DEL MODULO
# ==============================================================================
function Mostrar-Menu {
    try {
        $prefs = Get-MpPreference -ErrorAction Stop
    }
    catch {
        Write-Host " ERROR al leer preferencias de Defender: $_" -ForegroundColor Red
        return $null
    }

    Clear-Host
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host "   ESCUDO DEFENDER: GESTION DE SEGURIDAD" -ForegroundColor Cyan
    Write-Host "======================================================" -ForegroundColor Cyan

    $puaStatus    = if ($prefs.PUAProtection -eq 1) { "ACTIVADO" } else { "DESACTIVADO" }
    $cloudStatus  = if ($prefs.CloudBlockLevel -ne 0) { "ALTO" } else { "NORMAL" }
    $ransomStatus = if ($prefs.EnableControlledFolderAccess -eq 1) { "ACTIVADO" } else { "DESACTIVADO" }
    $netStatus    = if ($prefs.EnableNetworkProtection -eq 1) { "ACTIVADO" } else { "DESACTIVADO" }

    Write-Host " [1] Proteccion PUA:         $puaStatus"
    Write-Host " [2] Nivel Nube:             $cloudStatus"
    Write-Host " [3] Anti-Ransomware:        $ransomStatus"
    Write-Host " [4] Proteccion de Red:      $netStatus"
    Write-Host ""
    Write-Host " [S] Salir al menu principal"
    Write-Host "======================================================"

    return $prefs
}

function Aplicar-Cambio {
    param($Accion)
    try {
        & $Accion
        Write-Host " Cambio aplicado correctamente." -ForegroundColor Green
    }
    catch {
        Write-Host " ERROR al aplicar el cambio: $_" -ForegroundColor Red
        Write-Host " Si Tamper Protection esta activa, desactivala primero" -ForegroundColor Yellow
        Write-Host " en Seguridad de Windows > Proteccion antivirus > Configuracion." -ForegroundColor Yellow
    }
    Start-Sleep -Seconds 1
}

while ($true) {
    $prefs = Mostrar-Menu
    if ($null -eq $prefs) { pause; return }

    $opcion = Read-Host "Elige una opcion"

    switch ($opcion) {
        "1" { Aplicar-Cambio { Set-MpPreference -PUAProtection $(if ($prefs.PUAProtection -eq 1) { 0 } else { 1 }) } }
        "2" { Aplicar-Cambio { Set-MpPreference -CloudBlockLevel $(if ($prefs.CloudBlockLevel -eq 0) { "High" } else { "0" }) } }
        "3" { Aplicar-Cambio { Set-MpPreference -EnableControlledFolderAccess $(if ($prefs.EnableControlledFolderAccess -eq 1) { 0 } else { 1 }) } }
        "4" { Aplicar-Cambio { Set-MpPreference -EnableNetworkProtection $(if ($prefs.EnableNetworkProtection -eq 1) { 0 } else { 1 }) } }
        "s" { return }
        default { Write-Host "Opcion no valida"; Start-Sleep -Seconds 1 }
    }
}